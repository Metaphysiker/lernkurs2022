import("d3").then(d3 => {
  window.d3 = d3;
});
